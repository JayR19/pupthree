<script>
            var resizefunc = [];
        </script>
        <script src="<?php echo base_url('resources/js/pace.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/js/jquery.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/js/bootstrap.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/js/waves.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/js/wow.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/js/jquery.nicescroll.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/js/jquery.scrollTo.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/chat/moment-2.2.1.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/jquery-sparkline/jquery.sparkline.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/jquery-detectmobile/detect.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/fastclick/fastclick.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/jquery-slimscroll/jquery.slimscroll.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/jquery-blockui/jquery.blockUI.js');?>" type="text/javascript"></script>
        
          <!-- sweet alerts -->
        <script src="<?php echo base_url('resources/assets/sweet-alert/sweet-alert.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/sweet-alert/sweet-alert.init.js');?>" type="text/javascript"></script>
        
        <!-- flot Chart -->
        <script src="<?php echo base_url('resources/assets/flot-chart/jquery.flot.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/flot-chart/jquery.flot.time.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/flot-chart/jquery.flot.tooltip.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/flot-chart/jquery.flot.resize.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/flot-chart/jquery.flot.pie.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/flot-chart/jquery.flot.selection.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/flot-chart/jquery.flot.stack.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/flot-chart/jquery.flot.crosshair.js');?>" type="text/javascript"></script>
        
        <!-- Counter-up -->
        <script src="<?php echo base_url('resources/assets/counterup/waypoints.min.js');?>" type="text/javascript"></script>
        <script src="<?php echo base_url('resources/assets/counterup/jquery.counterup.min.js');?>" type="text/javascript"></script>
        
        <!-- CUSTOM JS -->
        <script src="<?php echo base_url('resources/js/jquery.app.js');?>" type="text/javascript"></script>
        
        <!-- Dashboard -->
        <script src="<?php echo base_url('resources/js/jquery.dashboard.js');?>" type="text/javascript"></script>
        
        <!-- Chat -->
        <script src="<?php echo base_url('resources/js/jquery.chat.js');?>" type="text/javascript"></script>
        
        <!-- Todo -->
        <script src="<?php echo base_url('resources/js/jquery.todo.js');?>" type="text/javascript"></script>
        
        <script type="text/javascript">
            /* ==============================================
            Counter Up
            =============================================== */
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });
            });
        </script>

        
</body>
</html>
