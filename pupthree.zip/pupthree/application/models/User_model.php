<?php
class User_model extends CI_Model{
    public function __construct() {
        parent::__construct();
    }
    public function register(){
        $data = array(
            'email' =>  $this->input->post('txtemail'),
            'username' => $this->input->post('txtname'),
            'pass' => $this->input->post('password')
        );
        $this->db->insert('th_user', $data);
    }
    public function signin(){
        $email = $this->input->post('txtname');
        $password =  $this->input->post('password');
        
        $query = $this->db->get_where(
                'th_user', array('username' => $email, 'pass' => $password )
                );
        if($query->row_array() > 0){
            $this->session->set_userdata(
                    'user', $this->input->post('txtname'));
            return true;
        }else{
            return false;
        }
    }
    
}
